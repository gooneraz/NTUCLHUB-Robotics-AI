from cv2 import cv2

face_cascade=cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
camera = cv2.VideoCapture(0)
face_id = input('Please enter your name for face ID: ')
sample_number = 0

while camera.isOpened():
    _, video = camera.read() 
    grey_video = cv2.cvtColor(video,cv2.COLOR_BGR2GRAY)
    faces=face_cascade.detectMultiScale(grey_video, scaleFactor=1.05, minNeighbors=5,minSize=(100,100))

    for (x,y,w,h) in faces:
        cv2.rectangle(video,(x,y),(x+w,y+h),(0,255,0),5)
        sample_number = sample_number + 1
        cv2.imwrite(r"C:\Users\Student\Desktop\Python Training\Data Set 100\User_"+ face_id + '_face' + str(sample_number)+ ".jpg", grey_video[y:y+h, x:x+w])

    cv2.imshow('video',video) 
    k=cv2.waitKey(1)
   
    if sample_number>100:
        print("Saving Completed. Press q to exit program.")
        break

    if k & 0xFF== ord('q'):
        print("Turning off camera...")
        print("Camera off.")
        break

camera.release()
cv2.destroyAllWindows