import os
import numpy as np
from PIL import Image
from cv2 import cv2
import tkinter as tk

def Program_1_face_collection(face_id):
    face_detector=cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
    camera = cv2.VideoCapture(0)
    #face_id = input('Please enter the name for face ID: ')
    sample_number = 0

    while camera.isOpened():
        _, video = camera.read() 
        grey_video = cv2.cvtColor(video,cv2.COLOR_BGR2GRAY)
        faces=face_detector.detectMultiScale(grey_video, scaleFactor=1.05, minNeighbors=5,minSize=(100,100))

        for (x,y,w,h) in faces:
            cv2.rectangle(video,(x,y),(x+w,y+h),(0,255,0),5)
            sample_number = sample_number + 1
            print("Saving face " + str(sample_number) + "...")
            cv2.imwrite("data_set_GUI/User_"+ face_id + '_face' + str(sample_number)+ ".jpg", grey_video[y:y+h, x:x+w])
            break

        cv2.imshow('video',video)
        k = cv2.waitKey(1)

        if sample_number>49:
            print("Saving Completed. Press q to exit program.")
            break

        if k & 0xFF == ord ('q'):
            break

    camera.release()
    cv2.destroyAllWindows()

def Program_2_trainer():
    # Create Local Binary Patterns Histograms for face recognization
    recognizer = cv2.face.LBPHFaceRecognizer_create()

    # Using prebuilt frontal face training model, for face detection
    detector = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")

    def assure_path_exists(path):
        dir = os.path.dirname(path)
        if not os.path.exists(dir):
            os.makedirs(dir)

    # Create method to get the images and label data
    def getImagesAndLabels(path):

        # Get all file path
        imagePaths = [os.path.join(path,files) for files in os.listdir(path)] 
        
        # Initialize empty face sample
        faceSamples=[]
        
        # Initialize empty id
        ids = []

        # Loop all the file path
        for imagePath in imagePaths:

            # Get the image and convert it to grayscale
            PIL_img = Image.open(imagePath).convert('L')

            # PIL image to numpy array
            img_numpy = np.array(PIL_img,'uint8')

            # Get the image id
            id = int(os.path.split(imagePath)[-1].split("_")[1])

            # Get the face from the training images
            faces = detector.detectMultiScale(img_numpy)

            # Loop for each face, append to their respective ID
            for (x,y,w,h) in faces:

                # Add the image to face samples
                faceSamples.append(img_numpy[y:y+h,x:x+w])

                # Add the ID to IDs
                ids.append(id)

        # Pass the face array and IDs array
        return faceSamples,ids

    # Get the faces and IDs
    faces,ids = getImagesAndLabels('data_set_GUI')

    # Train the model using the faces and IDs
    recognizer.train(faces, np.array(ids))

    # Save the model into trainer.yml
    assure_path_exists('data_trainer_GUI/')
    recognizer.save('data_trainer_GUI/trainer.yml')

    label3.place_forget()
    label4.place_forget()

    label5 = tk.Label(window, text="Model Generated!",font=('times',20,'bold'))
    label5.place(x= 350,y=380)

    return

def Program_3_face_recognizer():

    # Create Local Binary Patterns Histograms for face recognization
    recognizer = cv2.face.LBPHFaceRecognizer_create()

    # Load the trained mode
    recognizer.read('data_trainer_GUI/trainer.yml')

    # Load prebuilt model for Frontal Face
    cascadePath = "haarcascade_frontalface_default.xml"

    # Create classifier from prebuilt model
    faceCascade = cv2.CascadeClassifier(cascadePath)

    # Set the font style
    font = cv2.FONT_HERSHEY_SIMPLEX

    # Initialize and start the video frame capture
    cam = cv2.VideoCapture(0)

    # Loop
    while True:
        # Read the video frame
        _, im =cam.read()

        # Convert the captured frame into grayscale
        gray = cv2.cvtColor(im,cv2.COLOR_BGR2GRAY)

        # Get all face from the video frame
        faces = faceCascade.detectMultiScale(gray, 1.2,5)

        # For each face in faces
        for(x,y,w,h) in faces:

            # Create rectangle around the face
            cv2.rectangle(im, (x-20,y-20), (x+w+20,y+h+20), (0,255,0), 4)

            # Recognize the face belongs to which ID
            Id, confidence = recognizer.predict(gray[y:y+h,x:x+w])

            # Check the ID if exist 
            #if(confidence<50):
            if(Id == 1):
                Id = "Lucas {0:.2f}%".format(round(100 - confidence, 2))

            elif(Id == 2):
                Id = "Vincent {0:.2f}%".format(round(100 - confidence, 2))

            else:
                Id = "Unknown"

            # Put text describe who is in the picture
            cv2.rectangle(im, (x-22,y-90), (x+w+22, y-22), (0,255,0), -1)
            cv2.putText(im, str(Id), (x,y-40), font, 1, (255,255,255), 3)


        # Display the video frame with the bounded rectangle
        cv2.imshow('im',im) 

        # If 'q' is pressed, close program
        if cv2.waitKey(10) & 0xFF == ord('q'):
            break

    # Stop the camera
    cam.release()

    # Close all windows
    cv2.destroyAllWindows()
    return

def on_click():

    def confirm_click():
        face_id = id_input.get()
        #print(face_id)
        label2.place_forget()
        button2.place_forget()
        id_input.place_forget()

        global label3 
        label3= tk.Label(window, text="ID Accepted and faces collected!",font=('times',20,'bold'))
        label3.place(x= 270,y=380)

        global label4
        label4 = tk.Label(window, text="Click Training for generate the AI model",font=('times',15))
        label4.place(x= 300,y=420)
   
        if face_id != 0:
            Program_1_face_collection(face_id)

        return()
        
    label2 = tk.Label(window, text="Please enter the face ID:",font=('times',20,'bold'))
    label2.place(x= 100,y=400)
    button2 = tk.Button(window, text="Confirm",font=('times',15),command=confirm_click)
    button2.place(x= 400,y=450)
    id_input = tk.Entry(window,width=30,font=('times',20))
    id_input.place(x=400,y=400)

    return


window = tk.Tk()
window.title("Face recognition system")
window.geometry("900x500")

label1 = tk.Label(window, text="Welcome to the Lucas System", font=('times',40,'bold'))
label1.place(x = 120, y = 0)

button1 = tk.Button(window, text="Data Collection",width=15,heigh=3,font= ('times',20),command=on_click)
button1.place(x = 100, y = 200)

button2 = tk.Button(window, text="Training",width=15,heigh=3,font= ('times',20),command=Program_2_trainer)
button2.place(x = 350, y = 200)

button3 = tk.Button(window, text="Recognizer",width=15,heigh=3,font= ('times',20),command=Program_3_face_recognizer)
button3.place(x = 600, y = 200)

window.mainloop()