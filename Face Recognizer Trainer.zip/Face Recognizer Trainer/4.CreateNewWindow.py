import tkinter

window = tkinter.Tk()
window.title("Face Recognition Window")
window.geometry("900x500")
window.configure(bg="orange")

def close_window(): 
    window.destroy()

label_1=tkinter.Label(window,text="Press Quit to exit this window", bg="orange", font=('times',45,'bold'))
label_1.place(x=80,y=30)

button1=tkinter.Button(window,text="Quit", bg="red", fg="white", width=15,height=1,font=('times',15), command=close_window)
button1.place(x=375,y=375)

text_input=tkinter.Entry(window,width=40,font=('times',15, 'bold'))
text_input.place(x=280,y=130)

window.mainloop()