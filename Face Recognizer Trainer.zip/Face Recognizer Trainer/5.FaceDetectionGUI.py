import tkinter

window = tkinter.Tk()
window.title("Face Recognition System")
window.geometry("900x500")
window.configure(bg="grey")

def close_window(): 
    window.destroy()

label_1=tkinter.Label(window,text="Face Recognition System", bg="grey", font=('times',45,'bold'))
label_1.place(x=130,y=40)

button1=tkinter.Button(window,text="Data Collection", bg="blue", fg="white", width=20,height=1,font=('times',15), command=close_window)
button1.place(x=150,y=175)

button2=tkinter.Button(window,text="Training", bg="blue", fg="white", width=20,height=1,font=('times',15), command=close_window)
button2.place(x=500,y=175)

button3=tkinter.Button(window,text="Face Detection Camera", bg="blue", fg="white", width=20,height=1,font=('times',15), command=close_window)
button3.place(x=150,y=225)

button4=tkinter.Button(window,text="Face Recognizer", bg="blue", fg="white", width=20,height=1,font=('times',15), command=close_window)
button4.place(x=500,y=225)

button5=tkinter.Button(window,text="Quit", bg="red", fg="white", width=20,height=1,font=('times',15), command=close_window)
button5.place(x=325,y=375)

# text_input=tkinter.Entry(window,width=40,font=('times',15, 'bold'))
# text_input.place(x=280,y=130)

window.mainloop()